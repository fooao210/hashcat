import sys
import os
from ultralytics import YOLO

def main():
    model_path = "best.pt"
    if not os.path.exists(model_path):
        if os.path.exists("1.pt"):
            model_path = "1.pt"
        else:
            print("ERROR: Model not found")
            sys.stdout.flush()
            return

    try:
        model = YOLO(model_path)
    except Exception as e:
        print(f"ERROR: {str(e)}")
        sys.stdout.flush()
        return

    print("READY")
    sys.stdout.flush()

    for line in sys.stdin:
        image_path = line.strip()
        if not image_path:
            continue
            
        if not os.path.exists(image_path):
            print("ERROR_FILE_NOT_FOUND")
            sys.stdout.flush()
            continue
            
        try:
            results = model(image_path, verbose=False)
            text = ""
            for r in results:
                sorted_boxes = sorted(r.boxes.data.tolist(), key=lambda x: x[0])
                text = ''.join([model.names[int(box[5])] for box in sorted_boxes])
                break 
            
            print(text if text else "EMPTY")
        except Exception as e:
            print(f"ERROR_PROCESSING")
            
        sys.stdout.flush()

if __name__ == "__main__":
    main()
